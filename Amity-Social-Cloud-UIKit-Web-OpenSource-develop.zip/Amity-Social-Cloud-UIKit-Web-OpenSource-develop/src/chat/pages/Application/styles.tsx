import styled from 'styled-components';

export const ApplicationContainer = styled.div`
  display: flex;
  height: 100%;
  width: 100%;
`;
