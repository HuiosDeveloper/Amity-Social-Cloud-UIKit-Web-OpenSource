export const LIKE_REACTION_KEY = 'like';
export const LOVE_REACTION_KEY = 'love';
export const FIRE_REACTION_KEY = 'fire';
